﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Hastane_otamasyon_sistemi
{
    internal class ConnectionString
    {
        public SqlConnection GetCon()
        {
            SqlConnection bağlanti = new SqlConnection();
            bağlanti.ConnectionString = @"Data Source=MAHMUT;Initial Catalog=HastaneOtomasyonDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";


            return bağlanti;
        }
    }
}
