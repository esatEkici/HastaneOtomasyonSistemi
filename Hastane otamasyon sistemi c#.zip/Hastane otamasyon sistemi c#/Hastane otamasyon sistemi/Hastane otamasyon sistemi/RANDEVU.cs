﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hastane_otamasyon_sistemi
{
    public partial class RANDEVU : Form
    {
        public RANDEVU()
        {
            InitializeComponent();
        }
        ConnectionString MyCon = new ConnectionString();
        private void fillHasta()
        {
            SqlConnection bağlanti = MyCon.GetCon();
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select HAdSoyad from HastaTbl",bağlanti);
            SqlDataReader rdr;
            rdr = komut.ExecuteReader();
            DataTable dt = new DataTable(); 
            dt.Columns.Add("HadSoyad", typeof(string));
            dt.Load(rdr);
            RadCb.ValueMember = "HadSoyad";
            RadCb.DataSource = dt;
            bağlanti.Close();



        }
        private void RANDEVU_Load(object sender, EventArgs e)
        {
            fillHasta();
            uyeler(); 
            reset(); 
        }
        void uyeler()
        {
            Hastalar hs = new Hastalar();
            string query = "select * from RandevuTbl";
            DataSet ds = hs.ShowHasta(query);
            RandevuDVG.DataSource = ds.Tables[0];
        }
        void filter()
        {
            Hastalar hs = new Hastalar();
            string query = "select * from RandevuTbl where HAdSoyad like '%" + AraTb.Text + "%'";
            DataSet ds = hs.ShowHasta(query);
            RandevuDVG.DataSource = ds.Tables[0];
        }
        void reset()
        {
            RadCb.SelectedIndex = -1;
            RTarih.Text = "";
            RSaatCb.Text = "";
        }  


        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ŞikayetDVG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            string query = "insert into RandevuTbl values('" + RadCb.SelectedValue.ToString() + "','" + RTarih.Text + "','" + RSaatCb.Text + "')";
            Hastalar Hs = new Hastalar();
            //try
            {
                Hs.HastaEkle(query);
                MessageBox.Show("Randevu Başarıyla Eklendi");
                uyeler();   
                reset();


            }
            //catch(Exception Ex)
            {
                //MessageBox.Show(Ex.Message);    
            }
        }
        int key = 0;

        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            Hastalar hs = new Hastalar();
            if (key == 0)
            {
                MessageBox.Show("Güncellenecek Randevuyu Seçiniz");
            }
            else
            {
                try
                {
                    string query = "Update RandevuTbl set HAdSoyad = '" + RadCb.SelectedValue.ToString() + "', HTarih = '" + RTarih.Text + "',HSaat = '" + RSaatCb.Text+  "' where RandevuId = " + key + ";";
                    hs.HastaSil(query);
                    MessageBox.Show("Randevu Başarıyla Güncellendi");
                    uyeler();
                    reset();

                }
                catch (Exception ex) 
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void RandevuDVG_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            RadCb.SelectedValue = RandevuDVG.SelectedRows[0].Cells[1].Value.ToString();
            RTarih.Text = RandevuDVG.SelectedRows[0].Cells[2].Value.ToString();
            RSaatCb.Text = RandevuDVG.SelectedRows[0].Cells[3].Value.ToString();
            if (RadCb.SelectedIndex == -1)
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(RandevuDVG.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void guna2GradientButton3_Click(object sender, EventArgs e)
        {
            Hastalar hs = new Hastalar();
            if (key == 0)
            {
                MessageBox.Show("Silinecek Randevuyu Seçiniz");
            }
            else
            {
                try
                {
                    string query = "delete from RandevuTbl where RandevuId = " + key + "";
                    hs.HastaSil(query);
                    MessageBox.Show("Randevu Başarıyla Silindi");
                    uyeler();
                    reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            AnaSayfa ana = new AnaSayfa();
            ana.Show();
            this.Hide();
        }

        private void AraTb_TextChanged(object sender, EventArgs e)
        {
            filter();
        }

        private void guna2GradientButton7_Click(object sender, EventArgs e)
        {
            ŞİKAYET sikayetgecis = new ŞİKAYET();
            sikayetgecis.Show();
            this.Hide();
        }

        private void guna2GradientButton9_Click(object sender, EventArgs e)
        {
            HASTA hastagecis = new HASTA();
            hastagecis.Show();
            this.Hide();
        }

        private void guna2GradientButton6_Click(object sender, EventArgs e)
        {
            Reçete recetegecis = new Reçete();
            recetegecis.Show();
            this.Hide();
        }
    }  
}
