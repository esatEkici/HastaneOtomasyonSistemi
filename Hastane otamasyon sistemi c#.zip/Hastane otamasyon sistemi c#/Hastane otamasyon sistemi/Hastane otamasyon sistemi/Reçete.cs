﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane_otamasyon_sistemi
{
    public partial class Reçete : Form
    {
        public Reçete()
        {
            InitializeComponent();
        }
        ConnectionString MyCon = new ConnectionString();
        private void fillHasta()
        {
            SqlConnection bağlanti = MyCon.GetCon();
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select HAdSoyad from HastaTbl", bağlanti);
            SqlDataReader rdr;
            rdr = komut.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("HadSoyad", typeof(string));
            dt.Load(rdr);
            HastaAdiCb.ValueMember = "HadSoyad";
            HastaAdiCb.DataSource = dt;
            bağlanti.Close();



        }
        private void fillMiktar()
        {
            SqlConnection bağlanti = MyCon.GetCon();
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select HAdSoyad from HastaTbl", bağlanti);
            SqlDataReader rdr;
            rdr = komut.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("HadSoyad", typeof(string));
            dt.Load(rdr);
            HastaAdiCb.ValueMember = "HadSoyad";
            HastaAdiCb.DataSource = dt;
            bağlanti.Close();



        }


        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Reçete_Load(object sender, EventArgs e)
        {
            fillHasta();
            uyeler();
            reset();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            AnaSayfa ana = new AnaSayfa();
            ana.Show();
            this.Hide();
        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
        void uyeler()
        {
            Hastalar hs = new Hastalar();
            string query = "select * from ReçeteTbl";
            DataSet ds = hs.ShowHasta(query);
            ReçeteDVG.DataSource = ds.Tables[0];
        }
        void filter()
        {
            Hastalar hs = new Hastalar();
            string query = "select * from ReçeteTbl where HAdSoyad like '%" + AraTb.Text + "%'";
            DataSet ds = hs.ShowHasta(query);
            ReçeteDVG.DataSource = ds.Tables[0];
        }
        void reset()
        {
            HastaAdiCb.SelectedItem = "";
            İlaçTb.Text = "";
            MiktarTb.Text = "";

        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            string query = "insert into ReçeteTbl values('" + HastaAdiCb.SelectedValue.ToString() + "','" + İlaçTb.Text + "','"+MiktarTb.Text+"')";
            Hastalar Hs = new Hastalar();
            //try
            {
                Hs.HastaEkle(query);
                MessageBox.Show("Reçete Başarıyla Eklendi");
                uyeler();
                reset();


            }
            //catch(Exception Ex)
            {
                //MessageBox.Show(Ex.Message);    
            }
        }

        private void ReçeteDVG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        int key = 0;
        private void ReçeteDVG_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            HastaAdiCb.Text = ReçeteDVG.SelectedRows[0].Cells[1].Value.ToString();
            İlaçTb.Text = ReçeteDVG.SelectedRows[0].Cells[2].Value.ToString();
            MiktarTb.Text = ReçeteDVG.SelectedRows[0].Cells[3].Value.ToString();
            if (HastaAdiCb.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(ReçeteDVG.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void guna2GradientButton3_Click(object sender, EventArgs e)
        {
            Hastalar hs = new Hastalar();
            if (key == 0)
            {
                MessageBox.Show("Silinecek Reçeteyi Seçiniz");
            }
            else
            {
                try
                {
                    string query = "delete from ReçeteTbl where RId = " + key + "";
                    hs.HastaSil(query);
                    MessageBox.Show("Reçete Başarıyla Silindi");
                    uyeler();
                    reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void AraTb_TextChanged(object sender, EventArgs e)
        {
            filter();
        }
        Bitmap bitmap;
        private void guna2GradientButton6_Click(object sender, EventArgs e)
        {
            int height = ReçeteDVG.Height;
            ReçeteDVG.Height = ReçeteDVG.RowCount * ReçeteDVG.RowTemplate.Height * 2;
            bitmap = new Bitmap(ReçeteDVG.Width, ReçeteDVG.Height);
            ReçeteDVG.DrawToBitmap(bitmap, new Rectangle(0, 10, ReçeteDVG.Width, ReçeteDVG.Height));
            ReçeteDVG.Height = height;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bitmap, 0, 0);
        }

        private void guna2GradientButton8_Click(object sender, EventArgs e)
        {
            ŞİKAYET sikayetgecis = new ŞİKAYET();
            sikayetgecis.Show();
            this.Hide();
        }

        private void guna2GradientButton10_Click(object sender, EventArgs e)
        {
            HASTA hastagecis = new HASTA();
            hastagecis.Show();
            this.Hide();
        }

        private void guna2GradientButton9_Click(object sender, EventArgs e)
        {
            RANDEVU randevugecis = new RANDEVU();
            randevugecis.Show();
            this.Hide();
        }
    }
}
