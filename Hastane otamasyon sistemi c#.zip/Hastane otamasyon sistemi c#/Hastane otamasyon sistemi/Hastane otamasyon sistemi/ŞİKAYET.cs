﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane_otamasyon_sistemi
{
    public partial class ŞİKAYET : Form
    {
        public ŞİKAYET()
        {
            InitializeComponent();
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            string query = "insert into ŞikayetTbl values('" + HastaŞikayetiTb.Text + "','" + TedaviYöntemiTb.Text + "')";
            Hastalar Hs = new Hastalar();
            //try
            {
                Hs.HastaEkle(query);
                MessageBox.Show("Şikayet Başarıyla Eklendi");
                uyeler();
                reset();


            }
            //catch(Exception Ex)
            {
                //MessageBox.Show(Ex.Message);    
            }
        }
        int key = 0;
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            Hastalar hs = new Hastalar();
            if (key == 0)
            {
                MessageBox.Show("Güncellenecek Şikayeti Seçiniz");
            }
            else
            {
                try
                {
                    string query = "Update ŞikayetTbl set HŞikayeti = '" + HastaŞikayetiTb.Text + "',HTedaviYöntemi = '" + TedaviYöntemiTb.Text + "' where ŞId = " + key + ";"; 
                    hs.HastaSil(query);
                    MessageBox.Show("Şikayet Başarıyla Güncellendi");
                    uyeler();
                    reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void guna2GradientButton3_Click(object sender, EventArgs e)
        {
            Hastalar hs = new Hastalar();
            if (key == 0)
            {
                MessageBox.Show("Silinecek Şikayeti Seçiniz");
            }
            else
            {
                try
                {
                    string query = "delete from ŞikayetTbl where ŞId = " + key + "";
                    hs.HastaSil(query);
                    MessageBox.Show("Şikayet Başarıyla Silindi");
                    uyeler();
                    reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        void uyeler()
        {
            Hastalar hs = new Hastalar();
            string query = "select * from ŞikayetTbl";
            DataSet ds = hs.ShowHasta(query);
            ŞikayetDVG.DataSource = ds.Tables[0];
        }
        void filter()
        {
            Hastalar hs = new Hastalar();
            string query = "select * from ŞikayetTbl where HŞikayeti like '%" + AraTb.Text + "%'";
            DataSet ds = hs.ShowHasta(query);
            ŞikayetDVG.DataSource = ds.Tables[0];
        }
        void reset()
        {
            HastaŞikayetiTb.Text = "";
            TedaviYöntemiTb.Text = "";

        }
        private void ŞİKAYET_Load(object sender, EventArgs e)
        {
            uyeler();
            reset();
        }

        private void ŞikayetDVG_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            HastaŞikayetiTb.Text = ŞikayetDVG.SelectedRows[0].Cells[1].Value.ToString();
            TedaviYöntemiTb.Text = ŞikayetDVG.SelectedRows[0].Cells[2].Value.ToString();
            if (HastaŞikayetiTb.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(ŞikayetDVG.SelectedRows[0].Cells[0].Value.ToString()); 
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            AnaSayfa ana = new AnaSayfa();
            ana.Show();
            this.Hide(); 
        }

        private void AraTb_TextChanged(object sender, EventArgs e)
        {
            filter();
        }

        private void guna2GradientButton6_Click(object sender, EventArgs e)
        {
            Reçete recetegecis = new Reçete();
            recetegecis.Show();
            this.Hide();
        }

        private void guna2GradientButton8_Click(object sender, EventArgs e)
        {
            RANDEVU randevugecis = new RANDEVU();
            randevugecis.Show();
            this.Hide();
        }

        private void guna2GradientButton9_Click(object sender, EventArgs e)
        {
            HASTA hastagecis = new HASTA();
            hastagecis.Show();
            this.Hide();
        }
    }
}
