﻿namespace Hastane_otamasyon_sistemi
{
    partial class GirişKontrol
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GirişKontrol));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.KullanıcıAdiTB = new Guna.UI2.WinForms.Guna2TextBox();
            this.ŞifreTB = new Guna.UI2.WinForms.Guna2TextBox();
            this.LOGİN = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1068, 100);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(131, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(272, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(595, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "EKİNCİ HASTANESİ OTOMASYONU";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(271, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Kullanıcı Adı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(346, 264);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Şifre:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // KullanıcıAdiTB
            // 
            this.KullanıcıAdiTB.BorderColor = System.Drawing.Color.Yellow;
            this.KullanıcıAdiTB.BorderRadius = 10;
            this.KullanıcıAdiTB.BorderThickness = 3;
            this.KullanıcıAdiTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.KullanıcıAdiTB.DefaultText = "";
            this.KullanıcıAdiTB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.KullanıcıAdiTB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.KullanıcıAdiTB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.KullanıcıAdiTB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.KullanıcıAdiTB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.KullanıcıAdiTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.KullanıcıAdiTB.ForeColor = System.Drawing.Color.Black;
            this.KullanıcıAdiTB.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.KullanıcıAdiTB.Location = new System.Drawing.Point(418, 207);
            this.KullanıcıAdiTB.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.KullanıcıAdiTB.Name = "KullanıcıAdiTB";
            this.KullanıcıAdiTB.PasswordChar = '\0';
            this.KullanıcıAdiTB.PlaceholderText = "";
            this.KullanıcıAdiTB.SelectedText = "";
            this.KullanıcıAdiTB.Size = new System.Drawing.Size(263, 36);
            this.KullanıcıAdiTB.TabIndex = 2;
            this.KullanıcıAdiTB.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // ŞifreTB
            // 
            this.ŞifreTB.BorderColor = System.Drawing.Color.Yellow;
            this.ŞifreTB.BorderRadius = 10;
            this.ŞifreTB.BorderThickness = 3;
            this.ŞifreTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ŞifreTB.DefaultText = "";
            this.ŞifreTB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ŞifreTB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ŞifreTB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ŞifreTB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ŞifreTB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ŞifreTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ŞifreTB.ForeColor = System.Drawing.Color.Black;
            this.ŞifreTB.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ŞifreTB.Location = new System.Drawing.Point(418, 253);
            this.ŞifreTB.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.ŞifreTB.Name = "ŞifreTB";
            this.ŞifreTB.PasswordChar = '*';
            this.ŞifreTB.PlaceholderText = "";
            this.ŞifreTB.SelectedText = "";
            this.ŞifreTB.Size = new System.Drawing.Size(263, 36);
            this.ŞifreTB.TabIndex = 2;
            // 
            // LOGİN
            // 
            this.LOGİN.BorderRadius = 10;
            this.LOGİN.BorderThickness = 3;
            this.LOGİN.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.LOGİN.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.LOGİN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.LOGİN.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.LOGİN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.LOGİN.FillColor = System.Drawing.Color.Yellow;
            this.LOGİN.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.LOGİN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.LOGİN.ForeColor = System.Drawing.Color.Black;
            this.LOGİN.Location = new System.Drawing.Point(469, 346);
            this.LOGİN.Name = "LOGİN";
            this.LOGİN.Size = new System.Drawing.Size(164, 41);
            this.LOGİN.TabIndex = 3;
            this.LOGİN.Text = "LOGİN";
            this.LOGİN.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(1028, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 38);
            this.label4.TabIndex = 5;
            this.label4.Text = "X";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // GirişKontrol
            // 
            this.AcceptButton = this.LOGİN;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1068, 533);
            this.Controls.Add(this.LOGİN);
            this.Controls.Add(this.ŞifreTB);
            this.Controls.Add(this.KullanıcıAdiTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GirişKontrol";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox KullanıcıAdiTB;
        private Guna.UI2.WinForms.Guna2TextBox ŞifreTB;
        private Guna.UI2.WinForms.Guna2GradientButton LOGİN;
        private System.Windows.Forms.Label label4;
    }
}

