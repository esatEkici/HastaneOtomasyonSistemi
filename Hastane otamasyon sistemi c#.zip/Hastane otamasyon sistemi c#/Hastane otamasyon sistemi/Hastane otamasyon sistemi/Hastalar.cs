﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Hastane_otamasyon_sistemi
{
    internal class Hastalar
    {
        public void HastaEkle(string query)
        {
            ConnectionString myconnection = new ConnectionString();
            SqlConnection bağlanti = myconnection.GetCon();
            SqlCommand komut = new SqlCommand();
            komut.Connection = bağlanti;
            bağlanti.Open();
            komut.CommandText = query;
            komut.ExecuteNonQuery();
            bağlanti.Close();
        }
        public void HastaSil(string query) 
        {
            ConnectionString myconnection = new ConnectionString();
            SqlConnection bağlanti = myconnection.GetCon();
            SqlCommand komut = new SqlCommand();
            komut.Connection = bağlanti;
            bağlanti.Open();
            komut.CommandText = query;
            komut.ExecuteNonQuery();
            bağlanti.Close();
        }
        public void HastaGüncelle(string query)
        {
            ConnectionString myconnection = new ConnectionString();
            SqlConnection bağlanti = myconnection.GetCon();
            SqlCommand komut = new SqlCommand();
            komut.Connection = bağlanti;
            bağlanti.Open();
            komut.CommandText = query;
            komut.ExecuteNonQuery();
            bağlanti.Close();
        }
        public DataSet ShowHasta(string query)
        {
            ConnectionString myconnection = new ConnectionString();
            SqlConnection bağlanti = myconnection.GetCon();
            SqlCommand komut = new SqlCommand();
            komut.Connection = bağlanti;
            komut.CommandText = query;
            SqlDataAdapter sda=new SqlDataAdapter(komut);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }
    }
}
